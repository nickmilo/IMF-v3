tags: #vocals
links: [[000 Index|Index]], [[040 Interests MOC|Interests]]

---
# Vocals

### Notable Links
Vocals - 50 Tongue Twisters [[201701040825]] 

### Custom Tongue Twisters
- Our bags are already packed