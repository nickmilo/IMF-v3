# Notes Template
This is a basic guide and template for taking notes, which should be processed later. 

- Metadata
	- created: 2020-06-01
	- type: book
	- author: Ta-Nehisi Coates
	- year: 2015
	- web: 


#### Kinds of Filenames
- Book - Between the World and Me - Coates2015
- Speech - Analogy as Core, Core as Analogy - Hofstadter2009
- Article - Title - AuthorYYYY
- Paper - RobinsonEtAl2010 - A Cognitive Control Perspective of Self-Control Strength and Its Depletion
