"To avoid criticism, do nothing, say nothing, be nothing.” - Elbert Hubbard

#onCriticism #onWhatOtherPeopleThink
