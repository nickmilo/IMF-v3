"Someday is not a day of the week.” - Denise Brennan-Nelson

#onProcrastination
