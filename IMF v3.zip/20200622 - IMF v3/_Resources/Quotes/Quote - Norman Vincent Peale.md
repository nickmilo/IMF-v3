Change your thoughts and you change your world.” - Norman Vincent Peale 

#onAttitude #onBelief