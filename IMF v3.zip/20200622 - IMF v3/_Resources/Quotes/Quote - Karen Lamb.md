"A year from now you may wish you had started today.” - Karen Lamb

#onDoing #onStarting
