Don’t wish it were easier, wish you were better.” - Jim Rohn 

#onImprovement 