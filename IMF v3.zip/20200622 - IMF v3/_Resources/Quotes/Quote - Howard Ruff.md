"It wasn’t raining when Noah built the ark.” - Howard Ruff

#onPreparation
