“Keep your face to the sunshine and you can never see the shadow.” - Helen Keller

#onAttitude
