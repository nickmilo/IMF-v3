"If you can't explain it simply, you don't understand it well enough."- Albert Einstein

#onThinking #onUnderstanding