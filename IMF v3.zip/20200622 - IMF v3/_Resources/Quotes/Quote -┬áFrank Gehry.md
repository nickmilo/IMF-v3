"You've got to bumble forward into the unknown.” - Frank Gehry

#onTheUnknown #onMarchingForward 
