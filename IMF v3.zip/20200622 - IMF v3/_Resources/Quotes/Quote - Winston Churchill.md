"Success is going from failure to failure without losing your enthusiasm.” - [[Winston Churchill]] 

[[onPerseverance]], [[onSuccess]]
