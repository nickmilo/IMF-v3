"Imagination is everything. It is the preview of life's coming attractions." - Albert Einstein

#onImagination #onThinking 
