If you aren’t going all the way, why go at all? - Joe Namath 

#onEffort #onCourage #onIntegrity #onDoing