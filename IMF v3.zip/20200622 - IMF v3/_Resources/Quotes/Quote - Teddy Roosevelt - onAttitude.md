Do what you can, where you are, with what you have.” - [[Teddy Roosevelt]] 

---
tags: #onMakingtheMost #onEffort #onAttitude #quotes250 #quotes
