“Tough times never last, but tough people do.” - Dr. Robert Schuller

#onToughness

