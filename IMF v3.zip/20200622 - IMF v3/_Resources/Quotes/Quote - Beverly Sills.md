"There are no short cuts to any place worth going.” - Beverly Sills

#onHardWork #onEffort #onDedication #onPerseverance
