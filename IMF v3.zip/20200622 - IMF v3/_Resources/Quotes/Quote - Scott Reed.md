"Choosing a goal and sticking to it changes everything.” - Scott Reed 

#onDiscipline #onDedication #onFocus #onStickToItNess