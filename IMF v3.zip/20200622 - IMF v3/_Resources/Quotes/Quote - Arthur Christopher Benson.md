Very often a change of self is needed more than a change of scene.” - Arthur Christopher Benson 

#onAttitude #onSelfControl