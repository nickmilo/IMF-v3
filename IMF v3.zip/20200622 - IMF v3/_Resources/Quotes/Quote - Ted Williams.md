Just keep going. Everybody gets better if they keep at it.” - Ted Williams 

#onImprovement #onReps #onPractice #onExcellence