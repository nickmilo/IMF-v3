Nothing stood in his way, except for whatever emotional upset he choose to hold onto. - Steven Pressfield 

---
tags: #quotes #quotes250 #onEmotionalAgility #onTemperance #onResistance
