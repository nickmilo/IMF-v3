"The road to Easy Street goes through the sewer.” - John Madden

#onEffort #onPerseverance #onDetermination
