"Make each day your masterpiece.” - John Wooden

#onMastery #onExcellence
