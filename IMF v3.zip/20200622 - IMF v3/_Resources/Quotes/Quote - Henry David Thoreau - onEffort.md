"You must not only aim right, but draw the bow with all your might.” - [[Henry David Thoreau]] 

#onEffort