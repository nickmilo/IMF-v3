"Even if you fall on your face, you’re still moving forward.” - Victor Kiam

#onProgress 
