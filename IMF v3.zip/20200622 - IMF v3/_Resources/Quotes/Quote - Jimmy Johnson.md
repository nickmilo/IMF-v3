"The difference between ordinary and extraordinary is that little extra.” - Jimmy Johnson

#onSmallThings
