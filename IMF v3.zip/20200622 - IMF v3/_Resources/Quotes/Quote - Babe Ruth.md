"Every strike brings me closer to the next home run.” - Babe Ruth

#onPractice #onReps
