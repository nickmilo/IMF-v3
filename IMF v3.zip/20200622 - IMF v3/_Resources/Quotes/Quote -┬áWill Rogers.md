"Even if you’re on the right track, you’ll get run over if you just sit there.” - Will Rogers

#onKeepingAnEdge 
