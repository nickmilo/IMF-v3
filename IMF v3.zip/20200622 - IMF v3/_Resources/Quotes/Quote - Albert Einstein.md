"Your imagination is your preview of life’s coming attractions.” - [[Albert Einstein]] 

#onImagination
