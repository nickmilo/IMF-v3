What the mind of man can conceive and believe, it can achieve.” - Napoleon Hill 

#onBelief #onImagination