"The more I want to get something done, the less I call it work.” - Richard Bach

#onEnthusiasm #onEnergy
