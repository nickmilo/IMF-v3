All are free to choose their thoughts. Some are free to choose their pursuits. And a few so free that they are enslaved in pursuit of their follies. - Nick Milo

I'm sure this was inspired by [[Quote - Count of Monte Cristo|The Count of Monte Cristo]] quote.



---
tags: #quotes #quotes100 #onFreedom
links:
created: 2015-01-22