"If there is no struggle, there is no progress.” - Frederick Douglass

#onChallenge #onGrowth #onPain
