"The purpose of our lives is to be happy.” - [[Dalai Lama]] 

#onPurpose
