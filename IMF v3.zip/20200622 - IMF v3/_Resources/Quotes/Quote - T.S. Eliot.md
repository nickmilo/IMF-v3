"Every moment is a fresh beginning.” - T.S. Eliot

#onBeginnings #onFreshStarts
