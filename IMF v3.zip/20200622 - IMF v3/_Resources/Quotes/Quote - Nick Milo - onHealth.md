
> Nothing tastes as good as a sharp mind feels.

#quotes #quotesMe #onNutrition #onHealth 

This is a riff on a much dumber quote from someone whose name doesn't get to enter my zettelkasten.