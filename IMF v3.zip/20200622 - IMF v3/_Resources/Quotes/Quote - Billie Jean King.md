Champions keep playing until they get it right.” - Billie Jean King 

#onExcellence #onChampions #onGreatness