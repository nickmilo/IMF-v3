If you can’t outplay them, outwork them.” - Ben Hogan 

#onEffort #onToughness