Light tomorrow with today.” - Elizabeth Barrett Browning

#onResponsibility #onCauseAndEffect
