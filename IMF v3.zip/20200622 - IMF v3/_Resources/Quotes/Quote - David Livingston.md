I will go anywhere as long as it is forward.” - David Livingston 

#onProgress #onHighMindedness