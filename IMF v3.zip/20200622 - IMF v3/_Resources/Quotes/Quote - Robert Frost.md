"The best way out is always through.” - [[Robert Frost]] 

#onToughTimes #onToughness #onResolve