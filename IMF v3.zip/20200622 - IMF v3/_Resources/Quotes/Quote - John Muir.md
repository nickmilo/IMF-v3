“The power of imagination makes us infinite.” - John Muir

#onImagination #onPower

