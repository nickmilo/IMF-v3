"When you come to a roadblock, take a detour.” - Mary Kay Ash 

#onAlternatives #onChangingCourse #onTakingABreak
