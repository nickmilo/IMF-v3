“All models are True in some sense, False in some sense, and Meaningless in some sense.” 

#onTruth

This is a Discordian quote. Discordianism is a brusquely tongue-in-cheek. This quote is profoundly true. It relates to the idea that [[Truth is Relative]].