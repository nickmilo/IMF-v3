"The journey of a thousand miles begins with one step.” - [[Lao Tzu]] 

#onStarting #onDoing #onAction 
