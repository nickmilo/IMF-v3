All you have to do is decide what to do with the time that is given to you - Gandalf the Grey

Written by J.R.R. Tolkien and in the movie Return of the King, which I watched with my friends and Steve on opening night 2003-12-17.

---
tags: #quotes
links:
created: 2011-12-17
