"There are no traffic jams along the extra mile.” - Roger Staubach

#onEffort #onExtraMile