In theory there is no difference between theory and practice. In practice there is. - Yogi Berra

#quotes