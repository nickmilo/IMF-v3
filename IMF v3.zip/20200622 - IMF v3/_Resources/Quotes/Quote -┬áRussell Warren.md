"Obsessed is just a word the lazy use to describe the dedicated.” - Russell Warren

#onObsession #onEffort #onEnthusiasm
