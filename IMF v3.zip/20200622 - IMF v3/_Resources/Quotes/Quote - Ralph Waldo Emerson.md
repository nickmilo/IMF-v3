The creation of a thousand forests is in one acorn.” - Ralph Waldo Emerson 

#onSmallThings