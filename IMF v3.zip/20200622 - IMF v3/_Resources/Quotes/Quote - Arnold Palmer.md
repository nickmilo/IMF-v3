Always make a total effort, even when the odds are against you.” - Arnold Palmer 

#onEffort #onIntegrity #onCourage