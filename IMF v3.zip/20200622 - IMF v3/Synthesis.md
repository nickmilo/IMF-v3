# Synthesis
 The combining of separate elements or substances to form a coherent whole.
 
## Example Usage, Keywords, Concepts, and Metaphors
- Thesis. Antithesis. Synthesis [[201408190641]] - ie Hegelian dialectic
- Chinese culture and Confucianism - Chinese civilization is the longest living because of its ability to synthesize disparate entities, like it's doing currently with Communism and Capitalism.
- The Borg - via assimilation

---
tags: #mentalModels #concepts
links: [[Concepts MOC]]
