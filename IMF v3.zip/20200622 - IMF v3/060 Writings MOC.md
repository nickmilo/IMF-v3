tags: #writings #MOC
links: [[000 Index|Index]], [[060 Writings MOC|Writings]], [[070 Journal MOC|Journal]]

---
# Writings
This is where you put your writings of all flavors.

### Main Writing Categories
- [[Stories MOC]]
- [[Letters MOC]]
- [[Essays MOC]]
- [[Speeches MOC]]
- [[Best Writings MOC]]


### Writing Projects
- [[YOUR WRITING PROJECT GOES HERE]] 