Get into the habit of answering complex questions by starting with: *"Part of the reason why is because..."*

---
tags: #tidbits
