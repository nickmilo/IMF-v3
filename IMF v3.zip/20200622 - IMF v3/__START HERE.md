In the File explorer, select "Sort by file name (A to Z)".
Now, you can always find this note in the sidebar ««« `__START HERE`. 

The Basics
- Let's get on the same page: [[ZK and IMF - Rapid Fire Answers]]
- Do we agree on PKM? [[Guiding Principles of Knowledge Management]]

The Overview
- Learn about the IMF Framework: [[IMF Intro]]
- Learn about MOCs: [[MOCs (Maps of Content) - Intro]]

The Walk-throughs
- Forge Evergreen Notes: [[On the process of forging evergreen notes]]
- Use MOCs (Maps of Content): [[The 3 phases of MOCs]] 
- Set up your Index:  [[Setting Up IMF]]

---
[[IMF MOC]]

---
[[Release Notes - IMF]]

---
*Disclaimer: If you are completely new, ignore all of this and just start making notes. Maybe come back after you have at least 100 notes.

---
created: 
modified: 2020-05-24

