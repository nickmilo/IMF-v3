tags: #cooking
links: [[040 Interests MOC|Interests]]

---
# Cooking
ingredients, chef, cook, sweet potatoes, avocado toast, balanced plate, roots, stem, and flowers, 