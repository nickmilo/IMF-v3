Here's a theme CyberDynalist is meant to be used listening to nightride.fm. 

It derives inspiration from:
1. **Dynalist**
2. **Cyberpunk 2077**
3. **Synthwave**
4. **Keanu Reeves**
5. **The Terminator**