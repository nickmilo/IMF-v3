# The 3 phases of MOCs, a coda
The 3 phases of MOCs are not distinct like these examples. They overlap. Don't get hung up on the stages; and don't view the process as linear. 

The process is overlapping and cyclical. In Italian 'coda' means 'tail', and in any cycle, the tail is closest to the head. So don't worry if you tack on random notes to a formulized MOC; you should. 

An MOC is rarely a finalized concrete statue. Instead, it should be able to freely evolve over time. Or you could just create a new one... ;)


---
tags: #IMF #pkm 
links: [[Maps of Contents MOC]]