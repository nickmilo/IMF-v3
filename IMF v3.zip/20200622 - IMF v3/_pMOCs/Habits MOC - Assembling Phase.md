tags: #habits, #PKM
links: [[010 Mind MOC]], [[Walking through the 3 phases of MOCs]]

# Habits MOC - Assembling Phase
*Collect, Curate, Incubate* - Put related stuff on a new digital workbench

I decided to compile old notes I collected on the topic of 'habits'. They are not organized yet.

[[201303102051 Habit Planning]]
[[201502201031 Habit Formation Research Article]]
[[201502201713 Habit Concepts and Theory]]
[[201910011142 Atomic Habits]]
[[201901250999 Resiliency Routines]]

---
Next: [[Habits MOC - Colliding Phase]]