tags: #letters #MOC
links: [[060 Writings MOC|Writings]] 

---
# Letters
Welcome to the Letters MOC. This could also be called "Correspondences", because it covers things you've written to others. 

### Emails
YYYYMMDD
YYYYMMDD
YYYYMMDD
YYYYMMDD

### Texts
YYYYMMDD
YYYYMMDD
YYYYMMDD
YYYYMMDD

### Online Posts
YYYYMMDD
YYYYMMDD
YYYYMMDD
YYYYMMDD