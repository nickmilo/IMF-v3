tags: #allegories #koans #intuitionPumps 
links: [[055 Figures MOC|Figures]]

---
## Allegories
Allegories are stories with a deeper, often hidden meaning. They provide something to chew on.

- [[Plato's Cave]]
- [[Bring Me the Rhinoceros]] ==Not provided==