tags: #PKM #MOC
links: [[000 Index|Index]] 

---
# PKM MOC
This is where we manage the system of "*Personal Knowledge Management*."

You'll find the majority of this at [[IMF MOC]]

### PKM Best Practices
PKM Possible Best Practices
List of Best Practices for PKM [[201908171004 Example]] 
Evernote Folders and Tags [[201903281805 Example]] - Use this to make sure no valuable tags have fallen through the cracks (even though they are already all here and searchable).

