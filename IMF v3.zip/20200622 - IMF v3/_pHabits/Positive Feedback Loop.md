# Positive Feedback Loop
"The more you feed me, the more I feed you."

"A positive feedback loop occurs in nature when the product of a reaction leads to an increase in that reaction.""

Related: [[Habits carry a ton of hidden inertia]]

---
tags: #concepts 
links: [[Concepts MOC]]