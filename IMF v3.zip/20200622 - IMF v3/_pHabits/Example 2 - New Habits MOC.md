tags: #habits 
links: [[010 Mind MOC]]

# Example - New Habits MOC
[[The neural formation of habits are additive - v1]]
[[The truest habit metaphors are additive - v1]]