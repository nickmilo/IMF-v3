For some reason I've called important habits a lot of different things over the years. (Maybe I should just call them "Important Habits".)

- **Champion Habits** - a term used in a April 2010 speech.
- **Keystone Habits** - habits that, when changed, set off a chain reaction that extends to all aspects of a person’s life - from Duhigg (February 2013)
- **Bookend Habits** - the start and end to my days (March 2013)
- **Golden and Silver Habits** - honestly, why do I keep trying out new names? (June 2014)
- **Micro Habits** - tiny questions we ask ourselves throughout the day that shape big results (circa 2014-2015)
- **Power Habits** - December 2016
- **Resiliency Routines** - habits to rebuild or maintain a sense of control in one's life (May 2018)
- Others I don't use but that exist
	- **Atomic Habits** - from James Clear (circa October 2019) At least I'm not alone with the affliction of trying to name really important habits.

Related: [[Power Actions]], but that's for another time.

---
tags: #habits #PD
created: 2020-05-29
links: [[Habits MOC - Colliding Phase#Day 2]]