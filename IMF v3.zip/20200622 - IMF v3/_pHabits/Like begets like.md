# Like begets like
[[Like begets like]] is the natural process of Evolution's [[Selfish Gene]]. 

because [[Natural Selection]] demands that organisms become more efficient to increase its chances of survival (see [[Survival of the Fittest]]). 

Said another way, evolution's [[Selfish Gene]] has a Prime Directive: survive. It this way, Nature is neutral. It grows what you feed it. You are what you eat. 

That means whatever you do, whatever tiny action or thought, creates neural pathways; and neural pathways strengthen with use (see: [[The neural formation of habits are additive]]).

---
tags: #habits #PD 
links: [[Habits MOC - Unifying Phase]]