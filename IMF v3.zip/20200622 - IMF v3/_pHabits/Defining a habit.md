# Defining a habit
A habit is a mirror, it gives what you give it—and what you were given is what you'll give. It's the immediate expression a [[Positive Feedback Loop]].

[[Habits carry a ton of hidden inertia]]. To change a habit requires conscious, deliberate effort. 

As you attempt to change a habit, you have to expend effort to reroute the train. [[Changing a habit is really about replacing a routine]].

---
tags: #habit 
links: [[Habits MOC - Colliding Phase#Day 2]]
created: 2020-05-29