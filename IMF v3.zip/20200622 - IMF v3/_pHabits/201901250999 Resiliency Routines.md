tags: #habits #PD
2018 Review: [[201901250859]] 

# Resiliency Routines
Around May 2018, I felt an instinctual pull to rebuild some routine and structure into my day. Due to my undiagonosed condition to nounify everything, I began to refer to these practices as *Resiliency Routines*. Others who have read Duhigg might refer to them as "Keystone Habits". Normal people might just say "things I do in the morning and at night." 

For me, in the briefest rendition, it just meant waking up earlier than normal, journaling, and working out. I had one unfair super tool in my arsenal: our new apartment complex had a sauna. So every morning resulted in a sauna-workout. In the sauna one morning I recognized that I was: *unhappy, unbalanced, and unproductive*. My morning trifecta—wake early, journal, and workout—helped remove the “un” from those prefixes. 

1. Wake early
2. Journal
3. Workout

## Links
Atomic Habits: [[201910011142]] 
Habit Planning: [[201303102051]] 
Golden Habits: [[201406289999]] 
PD Lists: [[201511121539]] 