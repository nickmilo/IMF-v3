# Cobwebs into Cables
Turning cobwebs into cables is a metaphor for strengthening neural connections through [[Reps|repetitions]].

> "Neurons that fire together wire together” - Rick Hanson

---
tags: #pd #habits #concepts
links:  [[Concepts MOC|Concepts]], [[Habits MOC - Unifying Phase]], [[IMF Intro]]