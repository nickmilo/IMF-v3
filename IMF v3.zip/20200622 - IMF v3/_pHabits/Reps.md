# Reps
*"Reps, Reps, Reps."*  

Learning, improving, deliberate practice…the underpinning of it all—the unspoken current flowing through any progression—is getting reps, in all forms, consistently and frequently.


---

#### Note to Self
In practicing a craft, just show up, and get reps: tiny reps, technical reps, reps from questions, reps by observation, reps by research, reps, reps, consistent, persistent reps! 

---
tags: #concepts
links: [[Concepts MOC]] — [[Benefits of IMF]]
