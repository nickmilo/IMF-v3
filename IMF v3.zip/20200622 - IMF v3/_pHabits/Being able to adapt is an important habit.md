### Being able to adapt is an important habit
No day is perfect. It's crucial to balance discipline with being flexible. Too much order is fragile. 

If your morning isn't perfect, deal with it. Lamenting over an interrupted routine won't get you anything worth having.

Be like the "bend but don't break" willow tree. Even when the storm comes, the willow is tough enough to bend with the blows and not break beneath them. Simple metaphor. Bend don't break. Roll with the punches. Have a little toughness. Be ready to adapt, often. 

---
tags: #habits #PD
links: [[Habits MOC - Unifying Phase]]
created: 2014-06-28
modified: 2020-05-28