### Preparing for the next day is an important habit
This should read as common sense. Still, a refresher is nice.

- Start the night before.
- Walk around if you can to get the blood flowing.
- Talk if you can to get the mind thinking. It's helpful to externalize and articulate the unspoken. 
- Ask: *Did you set out your clothes for the upcoming day?*

To be able to lay out your clothes for the next day, you have to mentally rehearse the sequence of events for tomorrow. This let's you find the discover any problems and remedy them before they happen. 

A little visualization and preparation is a small nightly habit that pays major dividends.  

---
tags: #AQ #habits
links: [[Habits MOC - Unifying Phase]]
created: 2014-06-28
modified: 2020-06-09