# How Should I Handle UIDs - Various Answers
Sometimes the best way of understanding something is hearing what people have to say about it. (This is a Draft Note.)

*I've heard UIDs are important...How Should I Handle UIDs?*

> I tried implementing UIDs at the beginning of file names, but don't like the random order of notes by date. I've recently started moving the UID to the end of the file name, so you still have the reference but it doesn't feel in the way. 
> 
> ---
> But I've still not found a particularly useful need for the UID because backlinks, tags and search seem to be all I need to find stuff - @Reggie

> I am removing all of mine as I am transferring my notes to from the old platform to his new one. @klass 

