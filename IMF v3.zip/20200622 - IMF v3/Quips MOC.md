tags: #quips ; #quotes100 ; #quotes250 
links: [[000 Index|Index]], [[050 Quotes MOC|Quotes]]

---
# Quips MOC

