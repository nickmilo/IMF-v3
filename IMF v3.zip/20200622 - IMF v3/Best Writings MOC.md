tags: #writings #TOC
links: [[060 Writings MOC|Writings]]

---
# Best of Writings
This includes excerpts from _journals, letters, essays, posts, quotes, quips, and metaphors_. It also includes other things I've created. 

**Best Practice**: When you find a good writing in, say 2019, it should be tagged with #writings2019

### Chronology
#writings2020
#writings2019
#writings2018
#writings2017
#writings2016 
#writings2015
#writings2014
#writings2013 
#writings2012 
#writings2011
#writings2010
#writings2009
#writings2008
#writings2007
#writings2006

### Unsorted
- Lists of Bits I've Created [[176600000890]]
	- [ ] This is a long evernote file that needs to be salvaged and born again as plain test.