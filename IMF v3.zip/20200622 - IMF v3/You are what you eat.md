# You are what you eat
Growing up, I'd here this around the dinner table. Of course you don't be broccoli if you eat broccoli. 

---
tags: #concepts 
links: [[Concepts MOC]]
