tags: #metaphors #MOC #PKM
links: [[055 Figures MOC|Figures]]

---
# Metaphors MOC
Metaphors paint a picture. 

### Domain List & Links to Examples
Over time, this will grow in complexity and develop categories (maybe from [[Thought Unpacking]] ==Not provided==. In the meantime, it's just a list.

NOTE: Pull from and compile these previous lists when you have time:

201910091348
201511151227
201303041419
200906180859


### Drafts
Electromagnetism [[Like a compass...]] 