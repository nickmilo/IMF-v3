# Priming
Usually a sub-concept of [[Framing]], Priming refers to things that affect our mental context. 




Link to my whole "prime the mind" stuff, which is about taking deliberate actions to prime your mind before entering new environments and situations. At the time, I gave it a little too much import as I was testing it. The underlying value is that it allows for a [[Sense of Control]], which is a fundamental building block of feeling good and successful throughout life.

---
tags: #stub2 
links: [[Concepts MOC]]