tags: #tidbits #MOC
links: [[000 Index|Index]], [[050 Quotes MOC|Quotes]]

---
# Tidbits MOC
This is where I capture brief nuggets of wisdom that are not quotes; they are more like actionable ideas. I'm not sure what structure will form here, so right now, it's just going to be a list.

## List of Tidbits
==NOTE: Links won't work.== This is just an example.
[[201903261940]]
[[154400000000]] 
[[201411231005]]