tags: #rhetoric #influence #persuasion
links: [[040 Interests MOC|Interests]]

---
# Rhetoric