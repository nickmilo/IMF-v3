# About IMF
The goal of IMF is to enhance the experience of working with your digital library. It provides flexibility, longevity, and a bevy of other [[Benefits of IMF|Benefits]].

If got any value out of this or would like to be part of an "Alpha" testing group starting in July, please reach out on discord at `nickmilo#6327`.

-nickmilo

---
tags: #pkm #IMF
links: [[IMF Intro]], [[IMF MOC]]
