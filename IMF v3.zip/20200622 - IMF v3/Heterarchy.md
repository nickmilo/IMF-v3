# Heterarchy
A heterarchy is an unranked (non-hierachical) system of organization, or where they possess the potential to be ranked a number of different ways. (Wikipedia)

In a digital library, [[MOCs (Maps of Content) - Intro|Content Maps]] are the main example of a heterarchy.

---
links: [[IMF Glossary]]