tags: #metaphors #TOC #PKM
links: [[000 Index|Index]], [[055 Figures MOC|Figures]]

---
# Figures
Figurative language represents a broad swath of rich expression. If quotes are one half of a commonplace book, then metaphors, allusions, and allegories are the other half. 

- [[Metaphors MOC]]
- [[Allusions MOC]]
	- [[Allusions MOC#Some Allusions from Literature]]
- [[Allegories MOC]]






