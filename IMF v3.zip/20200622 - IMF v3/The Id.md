# The "Id"
*aka the "It"*  
- The source of our bodily needs, wants, desires, and impulses, particularly our sexual and aggressive drives. 
- Aroused by increases in instinctual tension.
- The disorganized part of the personality structure that contains a human's basic, instinctual drives. 

## Related
[[No-Face]] - essentially embodies the Id

---
links: [[Concepts MOC]]
