tags: #TOC #travel #places
Index: [[000 Index|Index]], [[035 Places MOC|Places]]

---
# Places MOC
Welcome to the Places MOC. It is the most under-developed major category for me, but I value having a "map" for "places", it's rather apt.

### Main Travel Categories
Countries I've Been To
Travel Purgatory List

### Some Notable Places
Journal of My Travels to XYZ
Mind Palace XYZ