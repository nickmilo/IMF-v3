# Cassandra
A cassandra is a person who continually predicts misfortune, but is not believed. 

Beware the Ides of March relates to Cassandra.

Blind Guardian's "And then there was silence" has an allusion to Cassandra. 